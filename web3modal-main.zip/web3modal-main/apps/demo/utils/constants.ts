export const VARIANTS = {
  initial: {
    y: -4,
    opacity: 0
  },
  animate: {
    y: 0,
    opacity: 1
  },
  exit: {
    y: -4,
    opacity: 0
  }
}
