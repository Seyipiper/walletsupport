'use client'

import React from 'react'

export default function Web3ModalProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
