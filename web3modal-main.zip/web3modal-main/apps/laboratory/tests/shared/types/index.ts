export interface SessionParams {
  reqAccounts: string[]
  optAccounts: string[]
  accept: boolean
}
