export const DEVICES = ['Desktop Firefox', 'Desktop Brave', 'Desktop Chrome']
