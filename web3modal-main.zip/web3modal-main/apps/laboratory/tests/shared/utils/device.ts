import { DEVICES } from '../constants/devices'

export function getAvailableDevices(): string[] {
  return DEVICES
}
