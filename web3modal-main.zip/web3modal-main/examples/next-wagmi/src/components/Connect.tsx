'use client'

export default function Connect() {
  return <w3m-button />
}
