export const NavigationUtil = {
  URLS: {
    FAQ: 'https://walletconnect.com/faq'
  }
}
